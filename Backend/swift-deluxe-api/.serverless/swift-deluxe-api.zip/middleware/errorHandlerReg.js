// import { sendResponse } from "../responses/index.js";

// export const errorHandlerReg = () => ({
//     onError: (handler) => {
//         console.error("Error occurred:", handler.error); // Logowanie błędu w konsoli
//         const statusCode = handler.error.statusCode || 500; // Użyj statusu z błędu lub domyślnie 500
//         const message = handler.error.message || "Internal Server Error"; // Użyj wiadomości z błędu lub domyślnej wiadomości
//         handler.response = sendResponse(statusCode, { message });
//         return Promise.resolve(); // Middy wymaga zwrócenia Promise w przypadku błędów
//     },
// });



import { sendResponse } from "../responses/index.js";

export const errorHandlerReg = () => ({
    onError: (handler) => {
        console.error("Error occurred:", handler.error); // Logowanie błędu w konsoli
        const statusCode = handler.error.statusCode || 500; // Użyj statusu z błędu lub domyślnie 500
        const message = handler.error.message || "Internal Server Error"; // Użyj wiadomości z błędu lub domyślnej wiadomości
        handler.response = sendResponse(statusCode, { message });
        return Promise.resolve(); // Middy wymaga zwrócenia Promise w przypadku błędów
    },
});

