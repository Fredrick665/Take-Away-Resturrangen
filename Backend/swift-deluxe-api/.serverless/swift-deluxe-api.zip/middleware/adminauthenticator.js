// import middy from '@middy/core';
// import { authenticate } from "../../middleware/authenticate.js";
// import jwt from 'jsonwebtoken';

// const jwtSecret = process.env.JWT_SECRET;

// export const adminAuthenticator = () => ({
//     before: async (handler) => {
//         const authHeader = handler.event.headers.Authorization || handler.event.headers.authorization;

//         if (!authHeader || !authHeader.startsWith('Bearer ')) {
//             throw new Error('Unauthorized: No token provided');
//         }

//         const token = authHeader.split(' ')[1];

//         try {
//             const decoded = jwt.verify(token, jwtSecret);

//             // Dodanie informacji o użytkowniku do event
//             handler.event.user = decoded;

//             // Sprawdzanie, czy użytkownik jest adminem
//             if (decoded.role !== 'admin') {
//                 throw new Error('Forbidden: Only admins are allowed');
//             }
//         } catch (err) {
//             throw new Error(err.message === 'jwt expired' ? 'Token expired' : 'Unauthorized: Invalid token');
//         }
//     },
// });


//------------------------------------------------------------------------------------------

import jwt from 'jsonwebtoken';

const jwtSecret = process.env.JWT_SECRET;

export const adminAuthenticator = () => ({
    before: async (handler) => {
        // Pobieranie nagłówka Authorization
        const authHeader = handler.event.headers.Authorization;

        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            console.error('No token provided');
            throw new Error('Unauthorized: No token provided');
        }

        const token = authHeader.split(' ')[1];

        try {
            // Weryfikacja tokenu
            const decoded = jwt.verify(token, jwtSecret);
            console.log('Decoded token:', decoded);

            // Dodanie użytkownika do eventu
            handler.event.user = decoded;

            // Weryfikacja roli
            if (decoded.role !== 'admin') {
                console.error('Access denied: User is not an admin');
                throw new Error('Forbidden: Only admins are allowed');
            }
        } catch (err) {
            console.error('Authentication error:', err.message);
            throw new Error(err.message === 'jwt expired' ? 'Token expired' : 'Unauthorized: Invalid token');
        }
    },
});





// Författare Katerina 