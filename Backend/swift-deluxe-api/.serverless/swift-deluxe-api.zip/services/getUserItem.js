
// import { db } from './index.js';
// import { sendResponse } from '../responses/index.js';

// export const getUserItem = async (username) => {
//     console.log('User username', username)
//     try {
//         const params = {
//             TableName: 'users-db',
//             Key: {
//                 username: username // Partition key
//             }
//         };
//         console.log('Hejsan');
//         const { Item } = await db.get(params);
//         console.log('item', Item);
//         if (Item) {
//             return Item; // Zwracamy dane użytkownika, jeśli istnieje
//         } else {
//             // Zwracamy odpowiedź, jeśli użytkownik nie istnieje
//             return sendResponse(404, { message: "User with this username does not exist" });
//         }
//     } catch (error) {
//         console.log('Nu blev det galet');

//         console.error('Error fetching user by username:', error);
//         // Zwracamy błąd w odpowiedzi
//         return sendResponse(500, { message: "Error fetching user" });
//     }
// };


import { db } from './index.js';

export const getUserItem = async (username) => {
    console.log('Fetching user with username:', username);

    try {
        const params = {
            TableName: 'users-db',
            Key: { username }, // Partition key
        };

        const { Item } = await db.get(params); // Upewnij się, że używasz `.promise()` w SDK AWS
        console.log('Fetched item:', Item);

        return Item || null; // Zwróć dane użytkownika lub `null` jeśli użytkownik nie istnieje
    } catch (error) {
        console.error('Error fetching user by username:', error);
        console.error('Error stack:', error.stack);
        throw new Error('Error fetching user'); // Rzucamy wyjątek do obsługi przez kontroler
    }
};




///  Författare Katerina