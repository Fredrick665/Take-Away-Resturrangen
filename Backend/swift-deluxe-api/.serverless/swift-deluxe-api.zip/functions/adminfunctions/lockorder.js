
// import { UpdateCommand, GetCommand } from "@aws-sdk/lib-dynamodb"; // Import komend DynamoDB
// import { db } from "../services"; // Połączenie z bazą danych DynamoDB
// import { sendResponse, sendError } from "../responses"; // Funkcje do obsługi odpowiedzi

// export const lockOrder = async (event) => {
//     const { id } = JSON.parse(event.body); // Odczytujemy id zamówienia z body

//     if (!id) {
//         return sendError(400, "Order ID is required");
//     }

//     try {
//         // Pobieramy zamówienie z bazy danych
//         const existingOrder = await db.send(
//             new GetCommand({
//                 TableName: "Orders_SwiftDeluxe",
//                 Key: { id },
//             })
//         );

//         if (!existingOrder.Item) {
//             return sendError(404, "Order not found");
//         }

//         // Aktualizujemy status zamówienia na 'LOCKED'
//         const updateParams = {
//             TableName: "Orders_SwiftDeluxe",
//             Key: { id },
//             UpdateExpression: "SET #status = :status, updatedAt = :updatedAt",    // pozwala określić, które atrybuty chce zaktualizować (tu status zamówienia na "LOCKED").
//             ExpressionAttributeNames: {
//                 "#status": "status",
//             },
//             ExpressionAttributeValues: {    //,używane, aby bezpiecznie odwołać się do nazwy atrybutu w bazie danych (np. status).
//                 ":status": "LOCKED", // Zmieniamy status na 'LOCKED',
//                 ":updatedAt": new Date().toISOString(),
//             },
//             ReturnValues: "UPDATED_NEW",
//         };

//         // Wysyłamy komendę aktualizacji
//         const result = await db.send(new UpdateCommand(updateParams));    // do zaktualizowania zamówienia w bazie danych DynamoDB.

//         // Zwracamy odpowiedź
//         return sendResponse(200, {
//             message: "Order successfully locked!",
//             updatedAttributes: result.Attributes,
//         });
//     } catch (error) {
//         console.error("Error locking order:", error);
//         return sendError(500, "Could not lock the order");
//     }
// };





import { UpdateCommand, GetCommand } from "@aws-sdk/lib-dynamodb"; // Import komend DynamoDB
import { db } from "../../services/index.js"; // Połączenie z bazą danych DynamoDB
import { sendResponse, sendError } from "../../responses/index.js"; // Funkcje do obsługi odpowiedzi

export const lockOrder = async (event) => {
    console.log("Received event:", JSON.stringify(event));

    const { id, status } = JSON.parse(event.body); // Teraz odczytujemy także status

    if (!id || !status) {
        return sendError(400, "Order ID and status are required");
    }

    if (status.toLowerCase() !== "locked") {
        return sendError(400, "Invalid status value. Only 'locked' is allowed.");
    }

    try {
        console.log("Fetching existing order with ID:", id);

        const existingOrder = await db.send(
            new GetCommand({
                TableName: "Orders_SwiftDeluxe",
                Key: { id },
            })
        );

        if (!existingOrder.Item) {
            console.log("Order not found for ID:", id);
            return sendError(404, "Order not found");
        }

        console.log("Updating order status to LOCKED for ID:", id);

        const updateParams = {
            TableName: "Orders_SwiftDeluxe",
            Key: { id },  // id wybrane przez admina
            UpdateExpression: "SET #status = :status, updatedAt = :updatedAt, version = :newVersion",
            ConditionExpression: "version = :currentVersion",  // Sprawdzanie wersji przed aktualizacją
            ExpressionAttributeNames: {
                "#status": "status",
            },
            ExpressionAttributeValues: {
                ":status": "LOCKED",  // Zmiana statusu na 'locked'
                ":updatedAt": new Date().toISOString(),
                ":newVersion": currentVersion + 1,  // Zwiększ wersję
                ":currentVersion": currentVersion,  // Sprawdzenie, czy wersja się zgadza
            },
            ReturnValues: "UPDATED_NEW",
        };


        const result = await db.send(new UpdateCommand(updateParams));

        console.log("Update result:", result);

        return sendResponse(200, {
            message: "Order successfully locked!",
            updatedAttributes: result.Attributes,
        });
    } catch (error) {
        console.error("Error locking order:", error);
        return sendError(500, "Could not lock the order");
    }
};
