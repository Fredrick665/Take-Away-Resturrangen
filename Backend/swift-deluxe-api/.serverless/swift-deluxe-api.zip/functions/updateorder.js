const { DynamoDB } = require("@aws-sdk/client-dynamodb");
const {
  DynamoDBDocument,
  UpdateCommand,
  GetCommand,
} = require("@aws-sdk/lib-dynamodb");

const client = new DynamoDB();
const db = DynamoDBDocument.from(client);

const orderTableName = "Orders_SwiftDeluxe";

exports.updateOrderItemsAndMessage = async (event) => {
  try {
    const body = JSON.parse(event.body);
    const { id, orderItems, message } = body;

    if (!id || (!orderItems && !message)) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          error:
            "Order ID samt minst ett av 'orderItems' eller 'message' krävs",
        }),
      };
    }

    // Kontrollera om ordern existerar
    const getParams = {
      TableName: orderTableName,
      Key: { id },
    };

    const existingOrder = await db.send(new GetCommand(getParams));

    if (!existingOrder.Item) {
      return {
        statusCode: 404,
        body: JSON.stringify({ error: "Order hittades inte" }),
      };
    }

    // Bygg uppdateringsuttryck dynamiskt
    const updateExpressions = [];
    const expressionAttributeNames = {};
    const expressionAttributeValues = {};

    if (orderItems) {
      updateExpressions.push("#oi = :orderItems");
      expressionAttributeNames["#oi"] = "orderItems";
      expressionAttributeValues[":orderItems"] = orderItems;
    }

    if (message) {
      updateExpressions.push("#msg = :message");
      expressionAttributeNames["#msg"] = "message";
      expressionAttributeValues[":message"] = message;
    }

    const updateExpression = `SET ${updateExpressions.join(", ")}`;

    const updateParams = {
      TableName: orderTableName,
      Key: { id },
      UpdateExpression: updateExpression,
      ExpressionAttributeNames: expressionAttributeNames,
      ExpressionAttributeValues: expressionAttributeValues,
      ReturnValues: "UPDATED_NEW",
    };

    const result = await db.send(new UpdateCommand(updateParams));

    return {
      statusCode: 200,
      body: JSON.stringify({
        message: "Order uppdaterades framgångsrikt!",
        updatedAttributes: result.Attributes,
      }),
    };
  } catch (error) {
    console.error("Fel vid uppdatering av order:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Kunde inte uppdatera order" }),
    };
  }
};
