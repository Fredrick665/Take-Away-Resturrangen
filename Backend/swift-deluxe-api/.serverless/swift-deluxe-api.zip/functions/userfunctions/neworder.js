const { DynamoDBClient } = require("@aws-sdk/client-dynamodb"); // Importera DynamoDBClient
const { PutCommand } = require("@aws-sdk/lib-dynamodb"); // Importera PutCommand
const { v4: uuidv4 } = require("uuid");

const orderTableName = "Orders_SwiftDeluxe"; // Använd den korrekta tabellen för ordrar

// Skapa DynamoDB-klienten
const dynamoDBClient = new DynamoDBClient({ region: "eu-north-1" });

exports.neworder = async (event) => {
  try {
    const requestBody = JSON.parse(event.body);
    const { orderItems } = requestBody;

    // Kontrollera att orderItems finns och är en icke-tom array
    if (!orderItems || !Array.isArray(orderItems) || orderItems.length === 0) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          message: "orderItems är obligatoriskt och måste vara en array",
        }),
      };
    }

    // Skapa en unik identifierare för ordern
    const orderId = uuidv4();

    // Skapa en ny order
    const newOrder = {
      id: orderId, // Ändra till "id" som partition key för att matcha DynamoDB-tabellen
      orderItems: orderItems, // Här lagras de varor som beställts
      status: "PENDING", // Initial status på ordern
      createdAt: new Date().toISOString(), // Tidsstämpel för när ordern skapades
    };

    const params = {
      TableName: orderTableName,
      Item: newOrder, // Lägger in den nya ordern i Orders_SwiftDeluxe
    };

    // Sätt in ny order i orderdatabasen
    await dynamoDBClient.send(new PutCommand(params));

    return {
      statusCode: 200,
      body: JSON.stringify({ message: "Order skapad!", orderId: orderId }),
    };
  } catch (error) {
    console.error("Fel vid skapande av order:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: "Fel vid skapande av order" }),
    };
  }
};
