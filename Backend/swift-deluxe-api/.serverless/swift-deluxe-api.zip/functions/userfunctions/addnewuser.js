
// import middy from '@middy/core';
// import { validateRegistration } from "../../middleware/validateReg.js";
// import { errorHandlerReg } from "../../middleware/errorHandlerReg.js";
// import { db } from "../../services/index.js";
// import bcrypt from 'bcryptjs';
// import { v4 as uuidv4 } from 'uuid';

// // Funktion att registera
// export const registerUser = async (event) => {
//     const { username, email, password, repeatPassword, address, role = 'user' } = JSON.parse(event.body);

//     // Walidacja, czy hasła się zgadzają
//     if (password !== repeatPassword) {
//         return {
//             statusCode: 400,
//             body: JSON.stringify({
//                 success: false,
//                 message: "Passwords must be the same.",
//             }),
//         };
//     }

//     try {
//         // Hashowanie hasła
//         const hashedPassword = await bcrypt.hash(password, 10);

//         const userId = uuidv4();

//         // Checking if the user already exists in the database (uniqueness of username/email)
//         const existingUsername = await db.get({
//             TableName: 'users-db',
//             Key: { username },
//         });


//         if (existingUsername.Item) {
//             return {
//                 statusCode: 400,
//                 body: JSON.stringify({
//                     success: false,
//                     message: "Username is already taken.",
//                 }),
//             };
//         }

//         const existingEmail = await db.scan({
//             TableName: 'users-db',
//             FilterExpression: "email = :email",
//             ExpressionAttributeValues: {
//                 ":email": email,
//             },
//         });

//         if (existingEmail.Items && existingEmail.Items.length > 0) {
//             return {
//                 statusCode: 400,
//                 body: JSON.stringify({
//                     success: false,
//                     message: "E-mail is already taken.",
//                 }),
//             };
//         }



//         await db.put({
//             TableName: 'users-db',
//             Item: {
//                 username,      // PK
//                 userId,
//                 email,
//                 password: hashedPassword,
//                 address,
//                 role,
//             },
//         });

//         return {
//             statusCode: 201,
//             body: JSON.stringify({
//                 success: true,
//                 message: "User registered successfully.",
//             }),
//         };
//     } catch (error) {
//         console.error("User registration error:", error);
//         return {
//             statusCode: 500,
//             body: JSON.stringify({
//                 success: false,
//                 message: "An error occurred while registering the user.",
//             }),
//         };
//     }
// };

// export const handler = middy(registerUser)
//     .use(validateRegistration())
//     .use(errorHandlerReg());


import middy from '@middy/core';
import { validateRegistration, validatePasswords, validateEmailAndUsername } from "../../middleware/validateReg.js";
import { sendResponse, sendError } from "../../responses/index.js";
import { db } from "../../services/index.js";
import bcrypt from 'bcryptjs';
import { v4 as uuidv4 } from 'uuid';
import { errorHandlerReg } from "../../middleware/errorHandlerReg.js";

export const registerUser = async (event) => {
    const { username, email, password, repeatPassword, address, role = 'user' } = JSON.parse(event.body);

    // Walidacja haseł
    const passwordError = validatePasswords(password, repeatPassword);
    if (passwordError) {
        return sendError(400, passwordError);
    }

    // Walidacja unikalności emaila i nazwy użytkownika
    const usernameEmailError = await validateEmailAndUsername(username, email);
    if (usernameEmailError) {
        return sendError(400, usernameEmailError);
    }

    try {
        const hashedPassword = await bcrypt.hash(password, 10);
        const userId = uuidv4();

        await db.put({
            TableName: 'users-db',
            Item: {
                username,
                userId,
                email,
                password: hashedPassword,
                address,
                role,
            },
        });

        return sendResponse(201, { message: "User registered successfully." });
    } catch (error) {
        console.error("User registration error:", error);
        return sendError(500, "An error occurred while registering the user.");
    }
};

export const handler = middy(registerUser)
    .use(validateRegistration())
    .use(errorHandlerReg());




// Författare Katerina