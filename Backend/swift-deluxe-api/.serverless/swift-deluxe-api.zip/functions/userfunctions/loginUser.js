// import middy from '@middy/core';
// import { getUser } from "../../services/getUser.js";
// import { comparePasswords } from "../../utils/token.js";
// import { generateJWT } from "../../utils/token.js";
// import { sendResponse } from "../../responses/index.js";

// export const loginUser = async (event) => {
//     const { email, password } = JSON.parse(event.body);

//     if (!email || !password) {
//         return sendResponse(400, { message: "Email and password are required." });
//     }

//     try {
//         const user = await getUser(email);

//         if (!user) {
//             return sendResponse(404, { message: "User not found." });
//         }

//         // Lösenordsjämförelse
//         const isPasswordValid = await comparePasswords(password, user.password);
//         if (!isPasswordValid) {
//             return sendResponse(401, { message: "Invalid credentials." });
//         }

//         // Generowanie JWT tokena
//         const token = generateJWT({ userId: user.userId, email: user.email, role: user.role });
//         return sendResponse(200, { message: "Login successful.", token });
//     } catch (error) {
//         console.error("Error logging in:", error);
//         return sendResponse(500, { message: "Error logging in." });
//     }
// };

// export const handler = middy(loginUser);




//------------------------------------

// import middy from '@middy/core';
// import { getUserEmail } from "../../services/getUserEmail.js";
// import { comparePasswords } from "../../utils/token.js";
// import { generateJWT } from "../../utils/token.js";
// import { sendResponse } from "../../responses/index.js";

// export const loginUser = async (event) => {
//     const { email, password } = JSON.parse(event.body);

//     if (!email || !password) {
//         return sendResponse(400, { message: "Email and password are required." });
//     }

//     try {
//         // Należy najpierw znaleźć userId w odpowiedni sposób
//         const user = await getUserEmail(email); // Funkcja getUserByEmail musi wyciągnąć userId z bazy danych

//         if (!user) {
//             return sendResponse(404, { message: "User not found." });
//         }

//         // Teraz masz userId i sprawdzasz hasło
//         const isPasswordValid = await comparePasswords(password, user.password);
//         if (!isPasswordValid) {
//             return sendResponse(401, { message: "Invalid credentials." });
//         }

//         // Tworzenie tokenu JWT
//         const token = generateJWT({ userId: user.userId, email: user.email, role: user.role });
//         return sendResponse(200, { message: "Login successful.", token });
//     } catch (error) {
//         console.error("Error logging in:", error);
//         return sendResponse(500, { message: "Error logging in." });
//     }
// };

// export const handler = middy(loginUser);




// import middy from '@middy/core';
// import { getUserEmail } from "../../services/getUserEmail.js";
// import { comparePasswords } from "../../utils/token.js";
// import { generateJWT } from "../../utils/token.js";
// import { sendResponse } from "../../responses/index.js";

// export const loginUser = async (event) => {
//     const { email, password } = JSON.parse(event.body);

//     if (!email || !password) {
//         return sendResponse(400, { message: "Email and password are required." });
//     }

//     try {
//         console.log("Trying to fetch user with email:", email);
//         const user = await getUserEmail(email); // Funkcja getUserEmail musi wyciągnąć userId z bazy danych
//         console.log("Fetched user:", user);

//         if (!user) {
//             return sendResponse(404, { message: "User not found." });
//         }

//         const isPasswordValid = await comparePasswords(password, user.password);
//         console.log("Password validation result:", isPasswordValid);

//         if (!isPasswordValid) {
//             return sendResponse(401, { message: "Invalid credentials." });
//         }

//         const token = generateJWT({ userId: user.userId, email: user.email, role: user.role });
//         console.log("Generated JWT token:", token);

//         return sendResponse(200, { message: "Login successful.", token });
//     } catch (error) {
//         console.error("Error during login:", error);
//         return sendResponse(500, { message: "Error logging in." });
//     }
// };

// export const handler = middy(loginUser);




import middy from "@middy/core";
import { getUserItem } from "../../services/getUserItem.js";
import { comparePasswords } from "../../utils/token.js";
import { generateJWT } from "../../utils/token.js";
import { sendResponse } from "../../responses/index.js";
import { validateLogin } from "../../middleware/validateLogin.js";
import { errorHandlerReg } from "../../middleware/errorHandlerReg.js";

export const loginUser = async (event) => {
    const { username, password } = JSON.parse(event.body);

    try {
        console.log("Trying to fetch user with username:", username);
        const user = await getUserItem(username);
        console.log("Fetched user:", user);

        if (!user || !user.password) {
            console.error('User not found or password is missing');
            return sendResponse(404, { message: "Invalid username or password" });
        }

        const isPasswordValid = await comparePasswords(password, user.password);
        console.log("Password validation result:", isPasswordValid);

        if (!isPasswordValid) {
            return sendResponse(401, { message: "Invalid credentials." });
        }

        const token = generateJWT({ userId: user.userId, username: user.username, role: user.role });
        console.log("Generated JWT token:", token);

        return sendResponse(200, { message: "Login successful.", token });
    } catch (error) {
        console.error("Error during login:", error);
        throw new Error(error.message); // Błędy zostaną przechwycone przez errorHandlerReg
    }
};


export const handler = middy(loginUser)
    .use(validateLogin()) // Walidacja danych wejściowych
    .use(errorHandlerReg()); // Obsługa błędów





// Författare Katerina
// lagt till den fill för att inloggning kräver jämförelse av lösenord och generering av token.